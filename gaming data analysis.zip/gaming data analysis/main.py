import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import statsmodels.api as sm
from linearmodels.panel import PanelOLS
from statsmodels.tsa.api import ExponentialSmoothing
import os

OUTPUT_DIR = 'analysis_outputs'
os.makedirs(OUTPUT_DIR, exist_ok=True)

def save_plot(fig, filename):
    filepath = os.path.join(OUTPUT_DIR, filename)
    fig.savefig(filepath, bbox_inches='tight')
    plt.close(fig)

def clean_df(df):
    df = df.copy()
    df.dropna(how='all', inplace=True)
    df.dropna(axis=1, how='all', inplace=True)
    df.columns = [str(c).strip() for c in df.columns]
    missing_values = ['-', 'N/A', 'NaN', '', 'None']
    for col in df.select_dtypes(include=['object']).columns:
        df[col] = df[col].replace(missing_values, np.nan)
    df = df.map(lambda x: np.nan if isinstance(x, str) and x.strip() in missing_values else x)
    return df

def robust_to_numeric(series, errors='coerce'):
    return pd.to_numeric(series, errors=errors)

# --- Data Loading and Initial Cleaning ---
try:
    xls = pd.ExcelFile('Cleaned_Video_Game_Data_Final.xlsx')
    sheet_names = xls.sheet_names
    data = {sheet: xls.parse(sheet) for sheet in sheet_names}
except FileNotFoundError:
    print("Error: 'Cleaned_Video_Game_Data_Final.xlsx' not found.")
    exit()
except Exception as e:
    print(f"Error loading Excel file: {e}")
    exit()

cleaned_data = {name: clean_df(df) for name, df in data.items() if not df.empty}

try:
    with pd.ExcelWriter(os.path.join(OUTPUT_DIR, 'Cleaned_Final_Analysis_Ready.xlsx')) as writer:
        for name, df in cleaned_data.items():
            df.to_excel(writer, sheet_name=name[:30], index=False)
    print(f"Cleaned data saved to {os.path.join(OUTPUT_DIR, 'Cleaned_Final_Analysis_Ready.xlsx')}")
except Exception as e:
    print(f"Error saving cleaned workbook: {e}")

# --- Load data 2.xlsx - Sheet1.csv independently ---
data_2_path = 'data 2.xlsx - Sheet1.csv'
data_2_df_list = []

try:
    raw_df = pd.read_csv(data_2_path, header=None, dtype=str)
    raw_df = raw_df.fillna('')

    company_block_indices = []
    for i, row_val in enumerate(raw_df.iloc[:, 0]):
        if any(comp_name in row_val for comp_name in ["Microsoft Corp", "Tencent Holdings Ltd", "Sony Corp"]):
            company_block_indices.append(i)
    company_block_indices.append(len(raw_df))

    for i in range(len(company_block_indices) - 1):
        start_idx = company_block_indices[i]
        end_idx = company_block_indices[i+1]
        
        current_block_df = raw_df.iloc[start_idx:end_idx].copy()
        
        company_name_raw = current_block_df.iloc[0, 0].strip()
        company_name = company_name_raw.replace(' Corp (MSFT US) - 1', '').replace(' Holdings Ltd (700 HK) - 1', '').replace(' Corp (6758 JP) - 1', '').strip()

        header_row_loc = -1
        for row_idx_in_block in range(1, len(current_block_df)):
            row_content = current_block_df.iloc[row_idx_in_block, :].astype(str).str.cat(sep=',')
            if "FY 20" in row_content and "Millions" in row_content:
                header_row_loc = row_idx_in_block
                break
        
        if header_row_loc == -1:
            print(f"Warning: Could not find header row for {company_name}. Skipping block.")
            continue

        year_col_map = {}
        for col_idx, col_val in enumerate(current_block_df.iloc[header_row_loc, :]):
            col_val_str = str(col_val).strip()
            if 'FY ' in col_val_str and col_val_str.replace('FY ', '').isdigit():
                year = int(col_val_str.replace('FY ', ''))
                year_col_map[year] = col_idx

        if not year_col_map:
            print(f"Warning: No valid fiscal years found in header for {company_name}. Skipping block.")
            continue

        sorted_years = sorted(year_col_map.keys())
        sorted_col_indices = [year_col_map[year] for year in sorted_years]

        rd_row_df = current_block_df[current_block_df.iloc[:, 0].astype(str).str.contains('R&D Expense', na=False)]
        revenue_row_df = current_block_df[current_block_df.iloc[:, 0].astype(str).str.contains('Revenue', na=False)]

        if rd_row_df.empty or revenue_row_df.empty:
            print(f"Warning: R&D Expense or Revenue data not found for {company_name}. Skipping block.")
            continue
        
        rd_values = [robust_to_numeric(rd_row_df.iloc[0, col_idx]) for col_idx in sorted_col_indices]
        revenue_values = [robust_to_numeric(revenue_row_df.iloc[0, col_idx]) for col_idx in sorted_col_indices]

        min_len = min(len(sorted_years), len(rd_values), len(revenue_values))
        valid_years = sorted_years[:min_len]
        valid_rd_values = rd_values[:min_len]
        valid_revenue_values = revenue_values[:min_len]

        if valid_years and valid_rd_values and valid_revenue_values:
            temp_df = pd.DataFrame({
                'Company': company_name,
                'Year': valid_years,
                'R&D Expense': valid_rd_values,
                'Revenue': valid_revenue_values
            })
            data_2_df_list.append(temp_df)
        else:
            print(f"Skipping block for {company_name} due to insufficient valid data after extraction.")

    if data_2_df_list:
        data_2_df = pd.concat(data_2_df_list, ignore_index=True)
        data_2_df = data_2_df.dropna(subset=['Year', 'R&D Expense', 'Revenue', 'Company'])
        data_2_df['Year'] = data_2_df['Year'].astype(int)
        print(f"Successfully loaded and processed '{data_2_path}'.")
    else:
        data_2_df = pd.DataFrame()
        print(f"No data extracted from '{data_2_path}'.")

except FileNotFoundError:
    data_2_df = pd.DataFrame()
    print(f"Error: '{data_2_path}' not found. Skipping independent data 2 analysis.")
except Exception as e:
    data_2_df = pd.DataFrame()
    print(f"Error processing '{data_2_path}': {e}. Skipping independent data 2 analysis.")


# --- Exploratory Data Analysis (EDA) ---
print("\n--- Exploratory Data Analysis ---")
for name, df in cleaned_data.items():
    print(f"\n==== {name} ====")
    print(df.info())
    print(df.describe(include='all'))

    numerical_cols = df.select_dtypes(include=np.number).columns
    for col in numerical_cols:
        if df[col].dropna().nunique() > 1:
            fig = plt.figure(figsize=(8, 5))
            sns.histplot(df[col].dropna(), kde=True, bins=30)
            plt.title(f"Distribution of {col} in {name}")
            save_plot(fig, f"{name}_{col}_distribution.png")

    categorical_cols = df.select_dtypes(include='object').columns
    for col in categorical_cols:
        if df[col].nunique() < 50 and not df[col].isnull().all():
            top_categories = df[col].value_counts().head(10)
            if not top_categories.empty:
                fig = plt.figure(figsize=(10, 6))
                sns.barplot(x=top_categories.index, y=top_categories.values, palette='viridis')
                plt.title(f"Top Categories for {col} in {name}")
                plt.xlabel(col)
                plt.ylabel("Count")
                plt.xticks(rotation=45, ha='right')
                plt.tight_layout()
                save_plot(fig, f"{name}_{col}_top_categories.png")

# --- Company Financial Trends (using independently loaded data_2_df) ---
print("\n--- Company Financial Trends ---")
if not data_2_df.empty:
    df_financial = data_2_df.copy()
    financial_cols = ['R&D Expense', 'Revenue']

    for metric in financial_cols:
        if metric in df_financial.columns and 'Year' in df_financial.columns and 'Company' in df_financial.columns:
            plot_df = df_financial.dropna(subset=['Year', metric, 'Company'])
            if not plot_df.empty:
                fig = plt.figure(figsize=(12, 6))
                sns.lineplot(data=plot_df, x='Year', y=metric, hue='Company', marker='o')
                plt.title(f"{metric} Over Time by Company")
                plt.xlabel("Year")
                plt.ylabel(metric)
                plt.grid(True, linestyle='--', alpha=0.7)
                plt.legend(title='Company', bbox_to_anchor=(1.05, 1), loc='upper left')
                plt.tight_layout()
                save_plot(fig, f"{metric.replace(' ', '_')}_Over_Time.png")
            else:
                print(f"Not enough data to plot {metric} over time for financial data.")
        else:
            print(f"Required columns for {metric} trend plot (Year, {metric}, Company) not found in financial data.")
else:
    print("Independent financial data (data 2.xlsx - Sheet1.csv) not loaded or is empty for financial trend analysis.")

# --- Combine and Analyze Game Sales ---
print("\n--- Game Sales Analysis ---")
sales_dfs = [v for k, v in cleaned_data.items() if 'sales' in k.lower() or 'games' in k.lower()]
if sales_dfs:
    combined_sales = pd.concat(sales_dfs, ignore_index=True)
    combined_sales = clean_df(combined_sales)
    combined_sales.drop_duplicates(inplace=True)

    sales_columns = ['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales', 'Global_Sales']
    for col in sales_columns:
        if col in combined_sales.columns:
            combined_sales[col] = robust_to_numeric(combined_sales[col])

    if 'Publisher' in combined_sales.columns:
        top_publishers = combined_sales['Publisher'].value_counts().head(10)
        if not top_publishers.empty:
            fig = plt.figure(figsize=(12, 6))
            sns.barplot(x=top_publishers.index, y=top_publishers.values, palette='viridis')
            plt.title("Top 10 Publishers by Game Count")
            plt.xlabel("Publisher")
            plt.ylabel("Number of Games")
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            save_plot(fig, "Top_10_Publishers_by_Game_Count.png")

    if 'Global_Sales' in combined_sales.columns:
        fig = plt.figure(figsize=(10, 6))
        sns.histplot(combined_sales['Global_Sales'].dropna(), bins=50, kde=True, color='skyblue')
        plt.title("Distribution of Global Sales")
        plt.xlabel("Global Sales (millions)")
        plt.ylabel("Frequency")
        plt.tight_layout()
        save_plot(fig, "Distribution_of_Global_Sales.png")

    if 'Genre' in combined_sales.columns and 'Global_Sales' in combined_sales.columns:
        genre_sales = combined_sales.groupby('Genre')['Global_Sales'].sum().sort_values(ascending=False).head(10)
        if not genre_sales.empty:
            fig = plt.figure(figsize=(12, 7))
            sns.barplot(x=genre_sales.index, y=genre_sales.values, palette='magma')
            plt.title("Top 10 Genres by Global Sales")
            plt.xlabel("Genre")
            plt.ylabel("Total Global Sales (millions)")
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            save_plot(fig, "Top_10_Genres_by_Global_Sales.png")

    if 'Platform' in combined_sales.columns and 'Global_Sales' in combined_sales.columns:
        platform_sales = combined_sales.groupby('Platform')['Global_Sales'].sum().sort_values(ascending=False).head(10)
        if not platform_sales.empty:
            fig = plt.figure(figsize=(12, 7))
            sns.barplot(x=platform_sales.index, y=platform_sales.values, palette='plasma')
            plt.title("Top 10 Platforms by Global Sales")
            plt.xlabel("Platform")
            plt.ylabel("Total Global Sales (millions)")
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            save_plot(fig, "Top_10_Platforms_by_Global_Sales.png")

    if 'Year_of_Release' in combined_sales.columns and 'Global_Sales' in combined_sales.columns:
        sales_by_year = combined_sales.groupby('Year_of_Release')['Global_Sales'].sum().reset_index()
        sales_by_year['Year_of_Release'] = robust_to_numeric(sales_by_year['Year_of_Release'])
        sales_by_year.dropna(subset=['Year_of_Release'], inplace=True)
        sales_by_year['Year_of_Release'] = sales_by_year['Year_of_Release'].astype(int)
        fig = plt.figure(figsize=(12, 6))
        sns.lineplot(data=sales_by_year, x='Year_of_Release', y='Global_Sales', marker='o', color='darkgreen')
        plt.title("Global Sales Over Year of Release")
        plt.xlabel("Year of Release")
        plt.ylabel("Total Global Sales (millions)")
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.tight_layout()
        save_plot(fig, "Global_Sales_Over_Year_of_Release.png")

    if 'Critic_Score' in combined_sales.columns and 'Global_Sales' in combined_sales.columns:
        plot_df = combined_sales.dropna(subset=['Critic_Score', 'Global_Sales'])
        if not plot_df.empty:
            fig = plt.figure(figsize=(10, 6))
            sns.scatterplot(data=plot_df, x='Critic_Score', y='Global_Sales', alpha=0.6, color='purple')
            plt.title("Critic Score vs. Global Sales")
            plt.xlabel("Critic Score")
            plt.ylabel("Global Sales (millions)")
            plt.tight_layout()
            save_plot(fig, "Critic_Score_vs_Global_Sales.png")

    numeric_sales_cols = [col for col in sales_columns + ['Critic_Score', 'User_Score', 'Critic_Count', 'User_Count'] if col in combined_sales.columns]
    numeric_sales_cols_actual = combined_sales[numeric_sales_cols].select_dtypes(include=np.number).columns
    if not numeric_sales_cols_actual.empty and len(numeric_sales_cols_actual) > 1:
        corr_matrix = combined_sales[numeric_sales_cols_actual].corr()
        fig = plt.figure(figsize=(10, 8))
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f")
        plt.title("Correlation Matrix of Sales-Related Numerical Features")
        plt.tight_layout()
        save_plot(fig, "Sales_Correlation_Heatmap.png")
else:
    print("No relevant sheets found for game sales analysis.")

# --- Capital Strategy Clustering (using independently loaded data_2_df) ---
print("\n--- Capital Strategy Clustering ---")
if not data_2_df.empty:
    df_cluster = data_2_df.copy()
    required_cluster_cols = ['Revenue', 'R&D Expense']

    for col in required_cluster_cols:
        if col in df_cluster.columns:
            df_cluster[col] = robust_to_numeric(df_cluster[col])
        else:
            print(f"Missing column for clustering: {col}. Skipping clustering.")
            df_cluster = pd.DataFrame()
            break

    if not df_cluster.empty:
        cluster_data = df_cluster[required_cluster_cols].dropna()

        if not cluster_data.empty and len(cluster_data) >= 2:
            try:
                scaler = StandardScaler()
                scaled_data = scaler.fit_transform(cluster_data)

                distortions = []
                K_range = range(1, min(len(cluster_data) + 1, 5))
                if len(K_range) > 1:
                    for k in K_range:
                        kmeans_model = KMeans(n_clusters=k, random_state=42, n_init=10)
                        kmeans_model.fit(scaled_data)
                        distortions.append(kmeans_model.inertia_)

                    fig = plt.figure(figsize=(10, 6))
                    plt.plot(K_range, distortions, marker='o')
                    plt.title('Elbow Method for Optimal K')
                    plt.xlabel('Number of Clusters (K)')
                    plt.ylabel('Distortion (Inertia)')
                    plt.grid(True)
                    save_plot(fig, "Elbow_Method_Clustering.png")

                n_clusters_chosen = min(3, len(cluster_data))
                if n_clusters_chosen >= 2:
                    kmeans = KMeans(n_clusters=n_clusters_chosen, random_state=42, n_init=10)
                    df_cluster.loc[cluster_data.index, 'Cluster'] = kmeans.fit_predict(scaled_data)

                    pca = PCA(n_components=min(2, scaled_data.shape[1]))
                    pca_result = pca.fit_transform(scaled_data)
                    df_cluster.loc[cluster_data.index, 'PCA1'] = pca_result[:, 0]
                    if pca_result.shape[1] > 1:
                        df_cluster.loc[cluster_data.index, 'PCA2'] = pca_result[:, 1]

                    fig = plt.figure(figsize=(10, 7))
                    if pca_result.shape[1] > 1:
                        sns.scatterplot(x='PCA1', y='PCA2', hue='Cluster', data=df_cluster.loc[cluster_data.index],
                                        palette='tab10', s=100, alpha=0.8)
                        plt.xlabel(f"Principal Component 1 ({pca.explained_variance_ratio_[0]*100:.2f}%)")
                        plt.ylabel(f"Principal Component 2 ({pca.explained_variance_ratio_[1]*100:.2f}%)")
                    else:
                        sns.histplot(x='PCA1', hue='Cluster', data=df_cluster.loc[cluster_data.index],
                                     palette='tab10', kde=True)
                        plt.xlabel(f"Principal Component 1 ({pca.explained_variance_ratio_[0]*100:.2f}%)")
                        plt.ylabel("Density")
                    plt.title(f"Capital Strategy Clusters (PCA - {n_clusters_chosen} Clusters)")
                    plt.grid(True, linestyle='--', alpha=0.6)
                    plt.tight_layout()
                    save_plot(fig, "Capital_Strategy_Clusters_PCA.png")

                    plot_cols = required_cluster_cols + ['Cluster']
                    pairplot_df = df_cluster.loc[cluster_data.index, plot_cols]
                    if not pairplot_df.empty:
                        fig = sns.pairplot(pairplot_df, hue='Cluster', palette='tab10', diag_kind='kde')
                        fig.fig.suptitle("Pairplot of Capital Strategy Clusters", y=1.02)
                        save_plot(fig, "Capital_Strategy_Clusters_Pairplot.png")

                    print(f"Clustering performed and {n_clusters_chosen} clusters identified.")
                else:
                    print(f"Not enough data points ({len(cluster_data)}) for meaningful clustering visualization (need at least 2 clusters).")
            except Exception as e:
                print(f"Error during clustering: {e}")
        else:
            print("Not enough valid data points for clustering after dropping NaNs (need at least 2).")
    else:
        print("Independent financial data (data 2.xlsx - Sheet1.csv) not loaded or is empty for capital strategy clustering.")

# --- Panel Regression (using independently loaded data_2_df) ---
print("\n--- Panel Regression Analysis ---")
if not data_2_df.empty:
    df_panel = data_2_df.copy()
    required_panel_cols = ['Revenue', 'R&D Expense', 'Company', 'Year']

    for col in ['Revenue', 'R&D Expense', 'Year']:
        if col in df_panel.columns:
            df_panel[col] = robust_to_numeric(df_panel[col])
        else:
            print(f"Missing column for panel regression: {col}. Skipping panel regression.")
            df_panel = pd.DataFrame()
            break

    if 'Company' in df_panel.columns:
        df_panel['Company'] = df_panel['Company'].astype(str).str.strip()
    else:
        print("Missing 'Company' column for panel regression. Skipping panel regression.")
        df_panel = pd.DataFrame()

    if not df_panel.empty:
        df_panel = df_panel.dropna(subset=required_panel_cols)

        if not df_panel.empty and len(df_panel['Company'].unique()) > 1 and len(df_panel['Year'].unique()) > 1:
            try:
                df_panel['Year'] = df_panel['Year'].astype(int)
                df_panel.set_index(['Company', 'Year'], inplace=True)

                exog_cols = [col for col in ['R&D Expense'] if col in df_panel.columns]
                if 'const' not in df_panel.columns:
                    df_panel['const'] = 1

                if exog_cols:
                    model = PanelOLS(df_panel['Revenue'], df_panel[['const'] + exog_cols], entity_effects=True)
                    results = model.fit()
                    print(results.summary)

                    fig = plt.figure(figsize=(10, 6))
                    plt.scatter(results.predicted_values, results.resids, alpha=0.5)
                    plt.axhline(0, color='red', linestyle='--')
                    plt.title("Residuals vs. Fitted Values (Panel Regression)")
                    plt.xlabel("Fitted Values")
                    plt.ylabel("Residuals")
                    save_plot(fig, "Panel_Regression_Residuals_vs_Fitted.png")

                    fig = plt.figure(figsize=(10, 6))
                    plt.scatter(df_panel['Revenue'], results.predicted_values, alpha=0.5)
                    min_val = min(df_panel['Revenue'].min(), results.predicted_values.min())
                    max_val = max(df_panel['Revenue'].max(), results.predicted_values.max())
                    plt.plot([min_val, max_val], [min_val, max_val], 'r--', lw=2)
                    plt.title("Actual vs. Predicted Revenue (Panel Regression)")
                    plt.xlabel("Actual Revenue")
                    plt.ylabel("Predicted Revenue")
                    save_plot(fig, "Panel_Regression_Actual_vs_Predicted.png")

                else:
                    print("No valid exogenous variables found for panel regression after cleaning.")
            except Exception as e:
                print(f"Error during panel regression: {e}")
        else:
            print("Not enough complete data or unique entities/years for panel regression after dropping NaNs.")
    else:
        print("df_panel is empty or missing required columns.")
else:
    print("Independent financial data (data 2.xlsx - Sheet1.csv) not loaded or is empty for panel regression.")

# --- Revenue Forecasting (using independently loaded data_2_df) ---
print("\n--- Revenue Forecasting ---")
if not data_2_df.empty:
    df_ts = data_2_df.copy()

    if 'Year' in df_ts.columns and 'Revenue' in df_ts.columns and 'Company' in df_ts.columns:
        df_ts['Year'] = robust_to_numeric(df_ts['Year'])
        df_ts['Revenue'] = robust_to_numeric(df_ts['Revenue'])
        df_ts['Company'] = df_ts['Company'].astype(str).str.strip()

        companies = df_ts['Company'].dropna().unique()
        forecast_horizon = 3

        for company in companies:
            company_df = df_ts[df_ts['Company'] == company].copy()
            company_df.dropna(subset=['Year', 'Revenue'], inplace=True)
            company_df = company_df.groupby('Year')['Revenue'].mean().reset_index()

            if len(company_df) >= 2:
                company_df = company_df.sort_values('Year')
                ts = company_df.set_index('Year')['Revenue']

                if len(ts) >= 2:
                    try:
                        ts_period = ts.asfreq('A').reindex(pd.PeriodIndex(ts.index, freq='A'))
                        if ts_period.isnull().any():
                            ts_period = ts_period.ffill().bfill()
                        if ts_period.isnull().any():
                            print(f"Skipping forecast for {company} due to insufficient valid data after imputation.")
                            continue

                        model = ExponentialSmoothing(ts_period, trend='add', seasonal=None, initialization_method="estimated")
                        fit = model.fit()
                        last_historical_year = ts_period.index.max().year
                        future_periods = pd.PeriodIndex(start=last_historical_year + 1, periods=forecast_horizon, freq='A')
                        forecast = fit.forecast(forecast_horizon)
                        forecast.index = future_periods.map(lambda x: x.year)

                        fig = plt.figure(figsize=(10, 6))
                        ts.plot(label='Historical Revenue', marker='o')
                        forecast.plot(label='Forecasted Revenue', linestyle='--', marker='x', color='red')
                        plt.title(f"{company} Revenue Forecast")
                        plt.xlabel("Year")
                        plt.ylabel("Revenue")
                        plt.legend()
                        plt.grid(True, linestyle='--', alpha=0.7)
                        plt.tight_layout()
                        save_plot(fig, f"{company.replace(' ', '_')}_Revenue_Forecast.png")
                    except Exception as e:
                        print(f"Error during forecasting for {company}: {e}")
                else:
                    print(f"Not enough valid data points for time series forecasting for company: {company} after aggregation.")
            else:
                print(f"Not enough valid data points for time series for company: {company}.")
    else:
        print("Required columns (Year, Revenue, Company) not found in financial data for forecasting.")
else:
    print("Independent financial data (data 2.xlsx - Sheet1.csv) not loaded or is empty for revenue forecasting.")

print(f"\nAll analysis complete. Plots are saved in the '{OUTPUT_DIR}' directory.")
